module.exports = {
  name: "puppybot",
  platform: "arduino-pico",
  title: "PuppyBot",
  description: "บอร์ดควบคุมหุ่นยนต์พลัง RP2040",
  author: "PrinceBot",
  website: "https://princebot.net",
  email: "print081@gmail.com",
  git: "https://github.com/PrinceBot-Ratthanin/kbpro-puppybot-board",
  image: "/static/cover.jpg",
  version: "2.7.0",
};
